// node_modules/@ionic/core/components/p-C53feagD.js
var o = (o2) => o2 && "" !== o2.dir ? "rtl" === o2.dir.toLowerCase() : "rtl" === (null === document || void 0 === document ? void 0 : document.dir.toLowerCase());

export {
  o
};
//# sourceMappingURL=chunk-JOQNI6T3.js.map

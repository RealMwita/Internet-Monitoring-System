// node_modules/@ionic/core/components/p-BTEOs1at.js
var t = class {
  constructor(t2, s3, i3, h2, e2) {
    this.id = s3, this.name = i3, this.disableScroll = e2, this.priority = 1e6 * h2 + s3, this.ctrl = t2;
  }
  canStart() {
    return !!this.ctrl && this.ctrl.canStart(this.name);
  }
  start() {
    return !!this.ctrl && this.ctrl.start(this.name, this.id, this.priority);
  }
  capture() {
    if (!this.ctrl) return false;
    const t2 = this.ctrl.capture(this.name, this.id, this.priority);
    return t2 && this.disableScroll && this.ctrl.disableScroll(this.id), t2;
  }
  release() {
    this.ctrl && (this.ctrl.release(this.id), this.disableScroll && this.ctrl.enableScroll(this.id));
  }
  destroy() {
    this.release(), this.ctrl = void 0;
  }
};
var s = class {
  constructor(t2, s3, i3, h2) {
    this.id = s3, this.disable = i3, this.disableScroll = h2, this.ctrl = t2;
  }
  block() {
    if (this.ctrl) {
      if (this.disable) for (const t2 of this.disable) this.ctrl.disableGesture(t2, this.id);
      this.disableScroll && this.ctrl.disableScroll(this.id);
    }
  }
  unblock() {
    if (this.ctrl) {
      if (this.disable) for (const t2 of this.disable) this.ctrl.enableGesture(t2, this.id);
      this.disableScroll && this.ctrl.enableScroll(this.id);
    }
  }
  destroy() {
    this.unblock(), this.ctrl = void 0;
  }
};
var i = "backdrop-no-scroll";
var h = new class {
  constructor() {
    this.gestureId = 0, this.requestedStart = /* @__PURE__ */ new Map(), this.disabledGestures = /* @__PURE__ */ new Map(), this.disabledScroll = /* @__PURE__ */ new Set();
  }
  createGesture(s3) {
    var i3;
    return new t(this, this.newID(), s3.name, null !== (i3 = s3.priority) && void 0 !== i3 ? i3 : 0, !!s3.disableScroll);
  }
  createBlocker(t2 = {}) {
    return new s(this, this.newID(), t2.disable, !!t2.disableScroll);
  }
  start(t2, s3, i3) {
    return this.canStart(t2) ? (this.requestedStart.set(s3, i3), true) : (this.requestedStart.delete(s3), false);
  }
  capture(t2, s3, i3) {
    if (!this.start(t2, s3, i3)) return false;
    const h2 = this.requestedStart;
    let e2 = -1e4;
    if (h2.forEach(((t3) => {
      e2 = Math.max(e2, t3);
    })), e2 === i3) {
      this.capturedId = s3, h2.clear();
      const i4 = new CustomEvent("ionGestureCaptured", { detail: { gestureName: t2 } });
      return document.dispatchEvent(i4), true;
    }
    return h2.delete(s3), false;
  }
  release(t2) {
    this.requestedStart.delete(t2), this.capturedId === t2 && (this.capturedId = void 0);
  }
  disableGesture(t2, s3) {
    let i3 = this.disabledGestures.get(t2);
    void 0 === i3 && (i3 = /* @__PURE__ */ new Set(), this.disabledGestures.set(t2, i3)), i3.add(s3);
  }
  enableGesture(t2, s3) {
    const i3 = this.disabledGestures.get(t2);
    void 0 !== i3 && i3.delete(s3);
  }
  disableScroll(t2) {
    this.disabledScroll.add(t2), 1 === this.disabledScroll.size && document.body.classList.add(i);
  }
  enableScroll(t2) {
    this.disabledScroll.delete(t2), 0 === this.disabledScroll.size && document.body.classList.remove(i);
  }
  canStart(t2) {
    return void 0 === this.capturedId && !this.isDisabled(t2);
  }
  isCaptured() {
    return void 0 !== this.capturedId;
  }
  isScrollDisabled() {
    return this.disabledScroll.size > 0;
  }
  isDisabled(t2) {
    const s3 = this.disabledGestures.get(t2);
    return !!(s3 && s3.size > 0);
  }
  newID() {
    return this.gestureId++, this.gestureId;
  }
}();

// node_modules/@ionic/core/components/p-Cl0B-RWe.js
var e = (t2, e2, n2, r2) => {
  const s3 = !!o(t2) && { capture: false, passive: !!r2.passive };
  let i3, c2;
  return t2.__zone_symbol__addEventListener ? (i3 = "__zone_symbol__addEventListener", c2 = "__zone_symbol__removeEventListener") : (i3 = "addEventListener", c2 = "removeEventListener"), t2[i3](e2, n2, s3), () => {
    t2[c2](e2, n2, s3);
  };
};
var o = (t2) => {
  if (void 0 === n) try {
    const e2 = Object.defineProperty({}, "passive", { get: () => {
      n = true;
    } });
    t2.addEventListener("optsTest", (() => {
    }), e2);
  } catch (t3) {
    n = false;
  }
  return !!n;
};
var n;
var r = (t2) => t2 instanceof Document ? t2 : t2.ownerDocument;
var s2 = (o2) => {
  let n2 = false, s3 = false, d = true, u = false;
  const l = Object.assign({ disableScroll: false, direction: "x", gesturePriority: 0, passive: true, maxAngle: 40, threshold: 10 }, o2), v = l.canStart, m = l.onWillStart, p = l.onStart, f = l.onEnd, y = l.notCaptured, h2 = l.onMove, _ = l.threshold, b = l.passive, D = l.blurOnStart, E = { type: "pan", startX: 0, startY: 0, startTime: 0, currentX: 0, currentY: 0, velocityX: 0, velocityY: 0, deltaX: 0, deltaY: 0, currentTime: 0, event: void 0, data: void 0 }, g = ((t2, e2, o3) => {
    const n3 = o3 * (Math.PI / 180), r2 = "x" === t2, s4 = Math.cos(n3), i3 = e2 * e2;
    let c2 = 0, a2 = 0, d2 = false, u2 = 0;
    return { start(t3, e3) {
      c2 = t3, a2 = e3, u2 = 0, d2 = true;
    }, detect(t3, e3) {
      if (!d2) return false;
      const o4 = t3 - c2, n4 = e3 - a2, l2 = o4 * o4 + n4 * n4;
      if (l2 < i3) return false;
      const v2 = Math.sqrt(l2), m2 = (r2 ? o4 : n4) / v2;
      return u2 = m2 > s4 ? 1 : m2 < -s4 ? -1 : 0, d2 = false, true;
    }, isGesture: () => 0 !== u2, getDirection: () => u2 };
  })(l.direction, l.threshold, l.maxAngle), x = h.createGesture({ name: o2.gestureName, priority: o2.gesturePriority, disableScroll: o2.disableScroll }), L = () => {
    n2 && (u = false, h2 && h2(E));
  }, T = () => !!x.capture() && (n2 = true, d = false, E.startX = E.currentX, E.startY = E.currentY, E.startTime = E.currentTime, m ? m(E).then(X) : X(), true), X = () => {
    D && (() => {
      if ("undefined" != typeof document) {
        const t2 = document.activeElement;
        (null == t2 ? void 0 : t2.blur) && t2.blur();
      }
    })(), p && p(E), d = true;
  }, Y = () => {
    n2 = false, s3 = false, u = false, d = true, x.release();
  }, j = (t2) => {
    const e2 = n2, o3 = d;
    Y(), o3 && (i2(E, t2), e2 ? f && f(E) : y && y(E));
  }, M = /* @__PURE__ */ ((t2, o3, n3, s4, i3) => {
    let c2, a2, d2, u2, l2, v2, m2, p2 = 0;
    const f2 = (r2) => {
      p2 = Date.now() + 2e3, o3(r2) && (!a2 && n3 && (a2 = e(t2, "touchmove", n3, i3)), d2 || (d2 = e(r2.target, "touchend", h3, i3)), u2 || (u2 = e(r2.target, "touchcancel", h3, i3)));
    }, y2 = (s5) => {
      p2 > Date.now() || o3(s5) && (!v2 && n3 && (v2 = e(r(t2), "mousemove", n3, i3)), m2 || (m2 = e(r(t2), "mouseup", _2, i3)));
    }, h3 = (t3) => {
      b2(), s4 && s4(t3);
    }, _2 = (t3) => {
      D2(), s4 && s4(t3);
    }, b2 = () => {
      a2 && a2(), d2 && d2(), u2 && u2(), a2 = d2 = u2 = void 0;
    }, D2 = () => {
      v2 && v2(), m2 && m2(), v2 = m2 = void 0;
    }, E2 = () => {
      b2(), D2();
    }, g2 = (o4 = true) => {
      o4 ? (c2 || (c2 = e(t2, "touchstart", f2, i3)), l2 || (l2 = e(t2, "mousedown", y2, i3))) : (c2 && c2(), l2 && l2(), c2 = l2 = void 0, E2());
    };
    return { enable: g2, stop: E2, destroy: () => {
      g2(false), s4 = n3 = o3 = void 0;
    } };
  })(l.el, ((t2) => {
    const e2 = a(t2);
    return !(s3 || !d) && (c(t2, E), E.startX = E.currentX, E.startY = E.currentY, E.startTime = E.currentTime = e2, E.velocityX = E.velocityY = E.deltaX = E.deltaY = 0, E.event = t2, (!v || false !== v(E)) && (x.release(), !!x.start() && (s3 = true, 0 === _ ? T() : (g.start(E.startX, E.startY), true))));
  }), ((t2) => {
    n2 ? !u && d && (u = true, i2(E, t2), requestAnimationFrame(L)) : (i2(E, t2), g.detect(E.currentX, E.currentY) && (g.isGesture() && T() || O()));
  }), j, { passive: b }), O = () => {
    Y(), M.stop(), y && y(E);
  };
  return { enable(t2 = true) {
    t2 || (n2 && j(void 0), Y()), M.enable(t2);
  }, destroy() {
    x.destroy(), M.destroy();
  } };
};
var i2 = (t2, e2) => {
  if (!e2) return;
  const o2 = t2.currentX, n2 = t2.currentY, r2 = t2.currentTime;
  c(e2, t2);
  const s3 = t2.currentX, i3 = t2.currentY, d = (t2.currentTime = a(e2)) - r2;
  if (d > 0 && d < 100) {
    const e3 = (i3 - n2) / d;
    t2.velocityX = (s3 - o2) / d * 0.7 + 0.3 * t2.velocityX, t2.velocityY = 0.7 * e3 + 0.3 * t2.velocityY;
  }
  t2.deltaX = s3 - t2.startX, t2.deltaY = i3 - t2.startY, t2.event = e2;
};
var c = (t2, e2) => {
  let o2 = 0, n2 = 0;
  if (t2) {
    const e3 = t2.changedTouches;
    if (e3 && e3.length > 0) {
      const t3 = e3[0];
      o2 = t3.clientX, n2 = t3.clientY;
    } else void 0 !== t2.pageX && (o2 = t2.pageX, n2 = t2.pageY);
  }
  e2.currentX = o2, e2.currentY = n2;
};
var a = (t2) => t2.timeStamp || Date.now();

export {
  i,
  h,
  s2 as s
};
//# sourceMappingURL=chunk-Q7PV5YUG.js.map

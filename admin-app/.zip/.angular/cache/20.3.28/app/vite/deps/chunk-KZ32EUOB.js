import {
  f
} from "./chunk-5ZNTDABU.js";

// node_modules/@ionic/core/components/p-D3xo7hqU.js
var i = (a, i2 = 0) => new Promise(((e2) => {
  r(a, i2, e2);
}));
var r = (a, i2 = 0, r2) => {
  let e2, t2;
  const n2 = { passive: true }, o2 = () => {
    e2 && e2();
  }, s2 = (i3) => {
    void 0 !== i3 && a !== i3.target || (o2(), r2(i3));
  };
  return a && (a.addEventListener("webkitTransitionEnd", s2, n2), a.addEventListener("transitionend", s2, n2), t2 = setTimeout(s2, i2 + 500), e2 = () => {
    void 0 !== t2 && (clearTimeout(t2), t2 = void 0), a.removeEventListener("webkitTransitionEnd", s2, n2), a.removeEventListener("transitionend", s2, n2);
  }), o2;
};
var e = (a, i2) => {
  a.componentOnReady ? a.componentOnReady().then(((a2) => i2(a2))) : d((() => i2(a)));
};
var t = (a) => void 0 !== a.componentOnReady;
var n = (a, i2 = []) => {
  const r2 = {};
  return i2.forEach(((i3) => {
    a.hasAttribute(i3) && (null !== a.getAttribute(i3) && (r2[i3] = a.getAttribute(i3)), a.removeAttribute(i3));
  })), r2;
};
var o = ["role", "aria-activedescendant", "aria-atomic", "aria-autocomplete", "aria-braillelabel", "aria-brailleroledescription", "aria-busy", "aria-checked", "aria-colcount", "aria-colindex", "aria-colindextext", "aria-colspan", "aria-controls", "aria-current", "aria-describedby", "aria-description", "aria-details", "aria-disabled", "aria-errormessage", "aria-expanded", "aria-flowto", "aria-haspopup", "aria-hidden", "aria-invalid", "aria-keyshortcuts", "aria-label", "aria-labelledby", "aria-level", "aria-live", "aria-multiline", "aria-multiselectable", "aria-orientation", "aria-owns", "aria-placeholder", "aria-posinset", "aria-pressed", "aria-readonly", "aria-relevant", "aria-required", "aria-roledescription", "aria-rowcount", "aria-rowindex", "aria-rowindextext", "aria-rowspan", "aria-selected", "aria-setsize", "aria-sort", "aria-valuemax", "aria-valuemin", "aria-valuenow", "aria-valuetext"];
var s = (a) => n(a, o);
var l = (a, i2, r2, e2) => a.addEventListener(i2, r2, e2);
var u = (a, i2, r2, e2) => a.removeEventListener(i2, r2, e2);
var c = (a, i2 = a) => a.shadowRoot || i2;
var d = (a) => "function" == typeof __zone_symbol__requestAnimationFrame ? __zone_symbol__requestAnimationFrame(a) : "function" == typeof requestAnimationFrame ? requestAnimationFrame(a) : setTimeout(a);
var m = (a) => !!a.shadowRoot && !!a.attachShadow;
var p = (a) => {
  if (a.focus(), a.classList.contains("ion-focusable")) {
    const i2 = a.closest("ion-app");
    i2 && i2.setFocus([a]);
  }
};
var f2 = (a, i2, r2, e2, t2) => {
  {
    let a2 = i2.querySelector("input.aux-input");
    a2 || (a2 = i2.ownerDocument.createElement("input"), a2.type = "hidden", a2.classList.add("aux-input"), i2.appendChild(a2)), a2.disabled = t2, a2.name = r2, a2.value = e2 || "";
  }
};
var b = (a, i2, r2) => Math.max(a, Math.min(i2, r2));
var v = (i2, r2) => {
  if (!i2) {
    const i3 = "ASSERT: " + r2;
    throw f(i3), new Error(i3);
  }
};
var w = (a) => {
  if (a) {
    const i2 = a.changedTouches;
    if (i2 && i2.length > 0) {
      const a2 = i2[0];
      return { x: a2.clientX, y: a2.clientY };
    }
    if (void 0 !== a.pageX) return { x: a.pageX, y: a.pageY };
  }
  return { x: 0, y: 0 };
};
var x = (a) => {
  const i2 = "rtl" === document.dir;
  switch (a) {
    case "start":
      return i2;
    case "end":
      return !i2;
    default:
      throw new Error(`"${a}" is not a valid value for [side]. Use "start" or "end" instead.`);
  }
};
var y = (a, i2) => {
  const r2 = a._original || a;
  return { _original: a, emit: h(r2.emit.bind(r2), i2) };
};
var h = (a, i2 = 0) => {
  let r2;
  return (...e2) => {
    clearTimeout(r2), r2 = setTimeout(a, i2, ...e2);
  };
};
var _ = (a, i2) => {
  if (null != a || (a = {}), null != i2 || (i2 = {}), a === i2) return true;
  const r2 = Object.keys(a);
  if (r2.length !== Object.keys(i2).length) return false;
  for (const e2 of r2) {
    if (!(e2 in i2)) return false;
    if (a[e2] !== i2[e2]) return false;
  }
  return true;
};
var T = (a) => "number" == typeof a && !isNaN(a) && isFinite(a);

export {
  i,
  e,
  t,
  n,
  s,
  l,
  u,
  c,
  d,
  m,
  p,
  f2 as f,
  b,
  v,
  w,
  x,
  y,
  _,
  T
};
//# sourceMappingURL=chunk-KZ32EUOB.js.map

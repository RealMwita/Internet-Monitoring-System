import {
  c,
  m
} from "./chunk-GULDXTCZ.js";
import {
  e
} from "./chunk-KZ32EUOB.js";
import {
  H,
  P
} from "./chunk-5ZNTDABU.js";
import {
  __async
} from "./chunk-WDMUDEB6.js";

// node_modules/@ionic/core/components/p-DHTSTb52.js
var n = () => {
  const n2 = window;
  n2.addEventListener("statusTap", (() => {
    H((() => {
      const o = document.elementFromPoint(n2.innerWidth / 2, n2.innerHeight / 2);
      if (!o) return;
      const m2 = m(o);
      m2 && new Promise(((o2) => e(m2, o2))).then((() => {
        P((() => __async(null, null, function* () {
          m2.style.setProperty("--overflow", "hidden"), yield c(m2, 300), m2.style.removeProperty("--overflow");
        })));
      }));
    }));
  }));
};
export {
  n as startStatusTap
};
//# sourceMappingURL=p-DHTSTb52-GD5AXGBF.js.map
